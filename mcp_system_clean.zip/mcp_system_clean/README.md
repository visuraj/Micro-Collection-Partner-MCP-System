# MCP System\n\nA web-based MCP System for managing Pickup Partners, orders, and wallet transactions.
